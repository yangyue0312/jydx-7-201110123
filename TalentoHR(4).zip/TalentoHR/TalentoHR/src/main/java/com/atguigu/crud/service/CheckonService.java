package com.atguigu.crud.service;

import com.atguigu.crud.bean.Checkon;
import com.atguigu.crud.bean.CheckonExample;
import com.atguigu.crud.bean.Employee;
import com.atguigu.crud.bean.EmployeeExample;
import com.atguigu.crud.dao.CheckonMapper;
import com.atguigu.crud.dao.EmployeeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CheckonService {
    @Autowired
    CheckonMapper checkonMapper;

    /**
     * 查询所有员工
     * @return
     * 新增功能来的
     */
    public List<Checkon> getAll() {
        // TODO Auto-generated method stub
        return checkonMapper.selectByExample(null);
    }

    /**
     * 员工保存
     * @param checkon
     */
    public void saveEmp(Checkon checkon) {
        // TODO Auto-generated method stub
        System.out.println("2");
        checkonMapper.insertSelective(checkon);
    }
    /**
     * 员工更新
     * @param checkon
     */
    public void updateEmp(Checkon checkon) {
        // TODO Auto-generated method stub
        checkonMapper.updateByPrimaryKeySelective(checkon);
    }


    /**
     * 按照员工id查询员工
     * @param id
     * @return
     */
    public Checkon getEmp(Integer id) {
        // TODO Auto-generated method stub
        Checkon checkon = checkonMapper.selectByPrimaryKey(id);
        return checkon;
    }

//    /**
//     * 员工更新
//     * @param employee
//     */
//    public void updateEmp(Employee employee) {
//        // TODO Auto-generated method stub
//        employeeMapper.updateByPrimaryKeySelective(employee);
//    }
//
//    /**
//     * 员工删除
//     * @param id
//     */
    public void deleteEmp(Integer id) {
        // TODO Auto-generated method stub
        checkonMapper.deleteByPrimaryKey(id);
    }

    public void deleteBatch(List<Integer> ids) {
        // TODO Auto-generated method stub
        CheckonExample example = new CheckonExample();
        CheckonExample.Criteria criteria = example.createCriteria();
        //delete from xxx where emp_id in(1,2,3)
        criteria.andEmpIdIn(ids);
        checkonMapper.deleteByExample(example);
    }

}

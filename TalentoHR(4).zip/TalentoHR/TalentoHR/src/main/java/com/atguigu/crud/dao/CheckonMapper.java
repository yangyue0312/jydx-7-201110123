package com.atguigu.crud.dao;

import com.atguigu.crud.bean.Checkon;
import com.atguigu.crud.bean.CheckonExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CheckonMapper {
    long countByExample(CheckonExample example);

    int deleteByExample(CheckonExample example);

    int deleteByPrimaryKey(Integer empId);

    int insert(Checkon record);

    int insertSelective(Checkon record);

    List<Checkon> selectByExample(CheckonExample example);

    Checkon selectByPrimaryKey(Integer empId);

    int updateByExampleSelective(@Param("record") Checkon record, @Param("example") CheckonExample example);

    int updateByExample(@Param("record") Checkon record, @Param("example") CheckonExample example);

    int updateByPrimaryKeySelective(Checkon record);

    int updateByPrimaryKey(Checkon record);
}
package dao;

import entity.OrderList;

public interface OrderListDao {
    void addOrderList(OrderList orderList);
}

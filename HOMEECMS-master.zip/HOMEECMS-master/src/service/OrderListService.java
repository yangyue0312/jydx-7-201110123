package service;

import entity.OrderList;

public interface OrderListService {
    void addOrderList(OrderList orderList);
}
